import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userInput:any="";
  passwordInput:any="";
  constructor(public router:Router) { }

  ngOnInit() {
    console.log("hi")
  }

  login(event: any){
    let user="deepak";
    let password="qwerty@1";

    console.log(event);
    if(user==this.userInput&& password==this.passwordInput){
      alert("your login is succusfully");
      this.router.navigate(['/index'])
    }
    else{
      alert("invalid login")
      console.log(this.userInput,this.passwordInput)
    }

  }


}
