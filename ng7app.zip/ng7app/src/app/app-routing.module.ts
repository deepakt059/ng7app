import { LoginComponent } from './hr/login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IndexComponent } from './hr/index/index.component';

const routes: Routes = [

{
  path:'',
  component:LoginComponent
},{
  path: 'index',
  component: IndexComponent
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
